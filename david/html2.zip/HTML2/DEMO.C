/*
  Demo HTML ( FreeHyperText ) program

  by Michal Stencl
*/

#include"html2.c"
#include"htmlfnc2.c"


#define HMTL_DEMO_NAME  "ex.htm"

int main ( void ) {

  char c[3];

  html_engine *engine;

  html_obs *out;
  html_obs *old;
  FILE *fo;

  engine  = html_engine_new(0, 0, 79, 24, 1, 5, 3, 0, 1, 1, 1, NULL);

  TEST = fopen("ex.to", "wt");

   /*
     I defineed new html for text mode, where

     1. left   origin is 0
     2. top    origin is 0
     3. right  origin is 79
     4. bottom origin is 24
     5. size between lines is 1
     6. block tabulation is   5
     7. dir   tabulation is   3
     8. I don't want to load images  0
     9. Horizontal line height is 1
    10. Line between 2 lines in dir type is 1
    11. The first calling of function hfuncredraw ( now it's NULL ) will
        be from the 1st line
   */


  /*
    - load html fonts, if you not set fonts loading function it makes nothing
  */
  html_load_fonts();



  /*
    - put output to engine.hobjectsout from file "ex.htm"
  */
  html_engine_out(engine, HTML_DEMO_NAME);

  if ( engine ) /* test if engine exist => system had enough memory for
  {                html loading and file exist */

    old = out = engine->hobjectsout;


    fo = fopen("exout.to" ,"wt");  /* make file for output */

    /* puts to demo file name of author and version of FHT */
    fprintf(fo, "\n%s version %s by %s\n", __FREE_HYPER_TEXT_NAME__,
                                           __FREE_HYPER_TEXT_VERSION__,
                                           __FREE_HYPER_TEXT_AUTHOR__);

    fprintf(fo, "-----------------------------------------------------------------------\n");


    old = NULL;

    while ( out ) {  /* repeat until the last object == NULL */

      char *mf = NULL;

      memset(c, 0, 3);

      /* transform aligment to chars */

      if ( out->halign & HTML_ALIGN_RIGHT ) c[0] = 'R';
      if ( out->halign & HTML_ALIGN_LEFT ) c[0] = 'L';
      if ( out->halign & HTML_ALIGN_CENTERX ) c[0] = 'C';

      if ( out->halign & HTML_ALIGN_UNDERLINED ) c[1] = 'U';


      /* transform font types to chars */

      if ( HTML_FONT_MAINTYPE(out->hfont) == HTML_FONT_NORMAL ) mf = "R";
      if ( HTML_FONT_MAINTYPE(out->hfont) == HTML_FONT_BOLD ) mf = "B";
      if ( HTML_FONT_MAINTYPE(out->hfont) == HTML_FONT_BI ) mf = "BI";
      if ( HTML_FONT_MAINTYPE(out->hfont) == HTML_FONT_ITALIC ) mf = "I";

      /* if next line, print it to file */

      if ( !old || out->hline != old->hline )
         fprintf(fo, "\nLine number #%i\n", out->hline);

      /* ...and write to file basic object settings */

      fprintf(fo, "<%s | text=%s | ref=%s | align=%s | fontsize=%i | type=%s | fcolor=%i | rect=%i %i %i %i >\n\n",
                HTMLid(out->htype), out->htext, out->href, c, HTML_FONT_WEIGHT(out->hfont),
                mf, out->hfcolor,
                out->hrect.hleft, out->hrect.htop, out->hrect.hright, out->hrect.hbottom);

      old = out;

      out = out->hnext; /* move to next object */

    };

    fclose(fo); /* close output file */

    html_engine_del(&engine); /* close html_engine */

    html_unload_fonts(); /* unload fonts */

    fclose(TEST);

    return 0;
};
