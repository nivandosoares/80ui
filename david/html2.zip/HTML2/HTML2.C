/*

  FreeHyperText 1.0 - library for easy HTML files loading

  Copyright (c) 1999 by Michal Stencl


  HTML2.C       is used for basic definitions.
  HTML2FNC.C    main translating functions

   o   This code is absolutly FREE.
   o   It's easy to port to all systems
   o   Please, if you any questions or ideas feel free to contact me at:


  e-mail:  stenclpmd@ba.telecom.sk

  web   :  http://www.home.sk/public/fht/

  web   :  http://www.home.sk/public/stencl/
*/

#ifndef __FHT_HTML2_INCLUDED__
#define __FHT_HTML2_INCLUDED__


#include<io.h>
#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<unistd.h>

#define __FREE_HYPER_TEXT_VERSION__       "1.00"
#define __FREE_HYPER_TEXT_NAME__          "FreeHyperText"
#define __FREE_HYPER_TEXT_AUTHOR__        "Michal Stencl"
#define __FREE_HYPER_TEXT_DATE__          "05. april 1999"




/* - PART FOR OWN REDECLARATION ************************************** */

#ifndef HTML_COLOR_MAKE
#define HTML_COLOR_MAKE             1
#endif


#ifndef HTML_CLASS
#define HTML_CLASS(x)              x
#endif

#ifndef HTML_PATH_MAX
#define HTML_PATH_MAX               79
#endif

/*
  font structure. Redefine by yourself
*/
#ifndef HTML_DEF_FONT
#define HTML_DEF_FONT               void
#endif

#ifndef HTML_FUNC_FONT_LOAD
#define HTML_FUNC_FONT_LOAD(f,w,h)  NULL
#endif

#ifndef HTML_FUNC_FONT_UNLOAD
#define HTML_FUNC_FONT_UNLOAD(f)
#endif

#ifndef HTML_FUNC_FONT_GETCHARWIDTH
#define HTML_FUNC_FONT_GETCHARWIDTH(f,c)              1
#endif

#ifndef HTML_FUNC_FONT_GETSTRWIDTH
#define HTML_FUNC_FONT_GETSTRWIDTH(f,str,s)           strlen(str)
#endif

#ifndef HTML_FUNC_FONT_GETHEIGHT
#define HTML_FUNC_FONT_GETHEIGHT(f)                   1
#endif



/*
  make long color from r,g,b
*/
#ifndef HTML_FUNC_COLOR_MAKERGB
#define HTML_FUNC_COLOR_MAKERGB(r,g,b)                0
#endif


/*
  font alignments
*/
#ifndef HTML_ALIGN_CENTERX
#define HTML_ALIGN_CENTERX     0x01
#endif

#ifndef HTML_ALIGN_RIGHT
#define HTML_ALIGN_RIGHT       0x02
#endif

#ifndef HTML_ALIGN_LEFT
#define HTML_ALIGN_LEFT        0x04
#endif

#ifndef HTML_ALIGN_TOP
#define HTML_ALIGN_TOP         0x08
#endif

#ifndef HTML_ALIGN_BOTTOM
#define HTML_ALIGN_BOTTOM      0x10
#endif


#ifndef HTML_ALIGN_UNDERLINED
#define HTML_ALIGN_UNDERLINED  0x20
#endif



/*
  bitmap structure
*/
#ifndef HTML_DEF_BITMAP
#define HTML_DEF_BITMAP             void
#endif

/*
  bitmap funcs
*/
#ifndef HTML_FUNC_BITMAP_DESTROY
#define HTML_FUNC_BITMAP_DESTROY(b)
#endif

#ifndef HTML_FUNC_BITMAP_LOAD
#define HTML_FUNC_BITMAP_LOAD(f)         NULL
#endif

/*
  HTML_FUNC_BITMAP_STRETCH stretch bitmap to another.
  it means, your definition of function must create new bitmap in "w", "h"
  sizes, stretch old bitmap "b" to new one, free old bitmap "b" and
  return new bitmap.
*/
#ifndef HTML_FUNC_BITMAP_STRETCH
#define HTML_FUNC_BITMAP_STRETCH(b,w,h)    NULL
#endif

#ifndef HTML_FUNC_BITMAP_GETWIDTH
#define HTML_FUNC_BITMAP_GETWIDTH(b)       0
#endif

#ifndef HTML_FUNC_BITMAP_GETHEIGHT
#define HTML_FUNC_BITMAP_GETHEIGHT(b)      0
#endif

/* define sizex of image that represented no-image */
#ifndef HTML_BITMAP_NOSIZEX
#define HTML_BITMAP_NOSIZEX                0
#endif

/* define sizey of image that represented no-image */
#ifndef HTML_BITMAP_NOSIZEY
#define HTML_BITMAP_NOSIZEY                0
#endif

/*
  font's names
*/
#ifndef HTML_FONT_NAMES
#define HTML_FONT_NAMES
char   *HTML_FONT_REGULAR_NAME    = NULL;
char   *HTML_FONT_ITALIC_NAME     = NULL;
char   *HTML_FONT_BOLD_NAME       = NULL;
char   *HTML_FONT_BOLDITALIC_NAME = NULL;
char   *HTML_FONT_DIRECTORY_NAME  = NULL;
#endif


#ifndef HTML_DEF_COLOR
#define HTML_DEF_COLOR     unsigned long
#endif


/*
  HTML error printf function. You can declare your self function like this:
  html_err = &my_printf();
*/
int __html_err_func (const char *str, ...){};
int (*html_err_func)(const char *str, ...) = &__html_err_func;



#ifndef max
#define max(x,y)    (((x) > (y)) ?  (x) : (y))
#endif
#ifndef min
#define min(x,y)    (((x) < (y)) ?  (x) : (y))
#endif
#ifndef lmax
#define lmax(x,y)   max((long)(x),(long)(y))
#endif
#ifndef lmin
#define lmin(x,y)   min((long)(x),(long)(y))
#endif


#define __HTML_UNIX_PATH_DECLARATION__

#define HTML_HEXANUM   "#"
#define C_HEXANUM      "0x"

#define BEGIN_S        "<"
#define BEGIN_E        ">"
#define END_S          "</"
#define END_E          ">"

#define html_com           char*

#define  HTML_COMMAND_MAX  1024

#define HTML_S             0
#define HEAD_S             1
#define TITLE_S            2
#define BODY_S             3
#define H1_S               4
#define H2_S               5
#define H3_S               6
#define H4_S               7
#define H5_S               8
#define H6_S               9
#define PARAGRAPH_S       10
#define PRE_S             11
#define ADDRESS_S         12
#define BLOCKQUOTE_S      13
#define UL_S              14
#define LI_S              15
#define OL_S              16
#define DIR_S             17
#define MENU_S            18
#define DL_S              19
#define DT_S              20
#define DD_S              21
#define ITALIC_S          22
#define BOLD_S            23
#define CITE_S            24
#define EM_S              25
#define STRONG_S          26
#define VAR_S             27
#define BR_S              28
#define HR_S              29
#define FONT_S            30
#define AHREF_S           31
#define IMG_S             32
#define U_S               33
#define CENTER_S          34
#define LH_S              35
#define TABLE_S           36
#define THOR_S            37
#define TVER_S            38


#define HTML_FONT_MAX         28

#define HTML_FONTS             7

#define HTML_FONT_H0           0
#define HTML_FONT_H1           1
#define HTML_FONT_H2           2
#define HTML_FONT_H3           3
#define HTML_FONT_H4           4
#define HTML_FONT_H5           5
#define HTML_FONT_H6           6

#define HTML_FONT_H0_BOLD      7
#define HTML_FONT_H1_BOLD      8
#define HTML_FONT_H2_BOLD      9
#define HTML_FONT_H3_BOLD     10
#define HTML_FONT_H4_BOLD     11
#define HTML_FONT_H5_BOLD     12
#define HTML_FONT_H6_BOLD     13

#define HTML_FONT_H0_ITALIC   14
#define HTML_FONT_H1_ITALIC   15
#define HTML_FONT_H2_ITALIC   16
#define HTML_FONT_H3_ITALIC   17
#define HTML_FONT_H4_ITALIC   18
#define HTML_FONT_H5_ITALIC   19
#define HTML_FONT_H6_ITALIC   20

#define HTML_FONT_H0_BI       21
#define HTML_FONT_H1_BI       22
#define HTML_FONT_H2_BI       23
#define HTML_FONT_H3_BI       24
#define HTML_FONT_H4_BI       25
#define HTML_FONT_H5_BI       26
#define HTML_FONT_H6_BI       27


HTML_DEF_FONT *HTMLFONTS[HTML_FONT_MAX] = {NULL, NULL, NULL, NULL, NULL, NULL, NULL,
            NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL,
            NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL}; /* global variable */

#define  HTMLFONTid(n) ((n<HTML_FONT_MAX&&n>=0)?HTMLFONTS[n]:NULL)



void  html_load_fonts ( void );
void  html_unload_fonts ( void );



#define HTML_FONT_NORMAL   0
#define HTML_FONT_BOLD     1
#define HTML_FONT_ITALIC   2
#define HTML_FONT_BI       3


int   ret_type_of_font ( HTML_DEF_FONT *fnt );
int   change_type_of_font ( int fnt, char type );
int   ret_weight_of_font ( int fnt );
int   change_weight_of_font ( int fnt, int weight );
int   ret_maintype_of_font ( int fnt );

#define HTML_FONT_TYPE(f)               ret_type_of_font(f)
#define HTML_FONT_MAINTYPE(nf)          ret_maintype_of_font(nf)
#define HTML_FONT_CHANGE_TYPE(nf,t)     change_type_of_font(nf, t)
#define HTML_FONT_WEIGHT(nf)            ret_weight_of_font(nf)
#define HTML_FONT_CHANGE_WEIGHT(nf,w)   change_weight_of_font(nf,w)


int   ret_align_id_from_str ( char *str );
#define  HTMLALIGNid(str) ret_align_id_from_str(str)

long  ret_size_id_from_str ( char *str, int *isdelta );
#define  HTMLSIZEid(str) ret_size_id_from_str(str,NULL)
#define  HTMLSIZEIDid(str,id) ret_size_id_from_str(str,id)

/*
  html object downloads structure.
  it use for save information about downloaded objects
*/

typedef struct html_dwns {
  char              *hid;       /* identification string */
  void              *hptr;      /* ptr to object */
  int                hidnum;    /* type of object. Can be one of xxx_S... */
  struct html_dwns  *hnext;     /* next object */
  char               hres[24];  /* reserved for future purpose */
} html_dwns;


char      *html_path2file ( char *path, char *id );

void      *html_obj_get_downloads ( html_dwns *main, char *id );
html_dwns *html_obj_ins_downloads ( html_dwns **main, char *id, int idnum, void *ptr );
html_dwns *html_obj_del_downloads ( html_dwns **main );
void      *html_obj_load_downloads ( html_dwns *main, char *path, char *id, int idnum );


#define HTML_DOWNLOADS_GET(id)      html_obj_get_downloads(HTML_DOWNLOADS, id)
#define HTML_DOWNLOADS_INS(id,n,p)  html_obj_ins_downloads(&HTML_DOWNLOADS, id, n, p)
#define HTML_DOWNLOADS_DEL()        html_obj_del_downloads(&HTML_DOWNLOADS)
#define HTML_DOWNLOADS_LOAD(id,n)   html_obj_load_downloads(HTML_DOWNLOADS, HTML_PATH_TO_FILE, id, n)


/*
  html lines structure.
  it use for save information about height of lines
*/
typedef struct html_lns {
  long               hline;     /* number of lines */
  int                hheight;   /* height of line */
  struct html_lns   *hnext;     /* next line */
  char               hres[8];   /* reserved for future purpose */
} html_lns;


html_lns *html_lines_get ( html_lns *main, long line );
int       html_lines_get_height ( html_lns *main, long line );
html_lns *html_lines_set ( html_lns **main, long line, int height );
html_lns *html_lines_set_max ( html_lns **main, long line, int height );
html_lns *html_lines_del ( html_lns **main );



#define html_bankspc_char_size  4
#define html_space_char_size    4

static char html_bankspc_char[html_bankspc_char_size+1] = {' ', '>', ',', 10, '\0'};

static char html_space_char[html_space_char_size+1] = {' ', 10, 9, 13, '\0'};



/*
  definition of origins
*/
typedef struct html_rect {

  long         hleft;
  long         htop;
  long         hright;
  long         hbottom;

} html_rect;



/*
  specific definition for table command
*/
typedef struct html_table {

  int                hrows;

  HTML_DEF_COLOR     hcolorblack;   /* text color */
  HTML_DEF_COLOR     hcolorwhite;   /* background color */
  HTML_DEF_COLOR     hcolorahref;   /* refernce text color */

  HTML_DEF_BITMAP   *hbackground;   /* image of backgound in table */
  struct html_rect   hframe;        /* frame of table */

} html_table;



 /* r - means that's for reading */

#define rHTMLtable_colorblack  ((HTML_OBJECTS.htable)?(*(HTML_OBJECTS.htable).hcolorblack):HTML_COLOR_BLACK)
#define rHTMLtable_colorwhite  ((HTML_OBJECTS.htable)?(*(HTML_OBJECTS.htable).hcolorwhite):HTML_COLOR_WHITE)
#define rHTMLtable_colorahref  ((HTML_OBJECTS.htable)?(*(HTML_OBJECTS.htable).hcolorahref):HTML_COLOR_AHREF)
#define rHTMLtable_background  ((HTML_OBJECTS.htable)?(*(HTML_OBJECTS.htable).hbackground):HTML_BACKGROUND)
#define rHTMLtable_frame       ((HTML_OBJECTS.htable)?(*(HTML_OBJECTS.htable).hframe):HTML_OBJECTS.hrect)
#define rHTMLtable_rows        ((HTML_OBJECTS.htable)?(*(HTML_OBJECTS.htable).hrows):HTML_OBJECTS.hrows)

 /* w - means that's for writing */

#define wHTMLtable_colorblack  if (HTML_OBJECTS.htable) *(HTML_OBJECTS.htable).hcolorblack
#define wHTMLtable_colorwhite  if (HTML_OBJECTS.htable) *(HTML_OBJECTS.htable).hcolorwhite
#define wHTMLtable_colorahref  if (HTML_OBJECTS.htable) *(HTML_OBJECTS.htable).hcolorahref
#define wHTMLtable_background  if (HTML_OBJECTS.htable) *(HTML_OBJECTS.htable).hbackground
#define wHTMLtable_frame       if (HTML_OBJECTS.htable) *(HTML_OBJECTS.htable).hframe
#define wHTMLtable_rows        if (HTML_OBJECTS.htable) *(HTML_OBJECTS.htable).rows




/*
  objects for html output
*/
typedef struct html_obs {

   int                  htype;               /* type of object */
   int                  htypewrite;
   int                  htypefirst;
   char                *htext;               /* text */
   char                *href;                /* reference */
   struct html_rect     hrect;               /* rect of html object */
   struct html_rect     hframe;              /* frame of html object */
   int                  hfromy;              /* indicates deltay from hrect.top */
   int                  hfont;               /* font of object */
   HTML_DEF_BITMAP     *himage;              /* image of object */
   HTML_DEF_COLOR       hfcolor;             /* foreground color of object */
   HTML_DEF_COLOR       hbcolor;             /* bacground color of object */
   char                 halign;              /* alignment of object */
   long                 hline;               /* line, where is of object situated */
   int                  hlinesize;           /* size of line */
   int                  hdirtype;            /* what type of directory */
   int                  hdirnumber;          /* what number of subdir in directory */
   char                 henter:1;            /*  */
   char                 hinsert:1;           /* if we want to insert object and text may be NULL */
   struct html_table   *htable;
   char                 hreserved[34];       /* reserved for future purposes */
   struct html_obs     *hnext;               /* next object in the directory */

} html_obs;




/*
  main definition actual for object engine
*/

typedef struct  html_engine {

  /* internal definitions */
  long              htimes[HTML_COMMAND_MAX];
  struct html_obs   hobjects;
  struct html_rect  hframe;
  HTML_DEF_COLOR    hcolorblack;
  HTML_DEF_COLOR    hcolorwhite;
  HTML_DEF_COLOR    hcolorahref;
  int               hlinesize;
  int               hblockquotetab;
  int               hblockdirtab;
  char              himagesload;
  char              hhorlinesize;
  int               hdirlinesize;
  long              hswitchfrom; /* this must be declared as how many lines go up to first switch call */
  void            (*hfuncredraw)();
  char             *hpathtofile;
  char             *hfilename;
  char             *hwhere;      /* current ptr in file */
  /* outputs definitions */
  long              hline;
  struct html_rect  hframeout;
  struct html_obs  *hobjectsout;
  struct html_dwns *hdownloads;
  HTML_DEF_BITMAP  *hbackground; /* background image */
  char              hstopinfo;
  char              hreserved[124];

} html_engine;

#define    HTML_ENGINE           html_engine
#define    HTML_DEF_ENGINE       HTML_ENGINE *engine

#define    HTML_FRAME            ((*engine).hframe)
#define    HTML_FRAMEOUT         ((*engine).hframeout)

#define    HTML_DOWNLOADS        ((*engine).hdownloads)

#define    HTML_TIMES            ((*engine).htimes)
#define    HTML_OBJECTS          ((*engine).hobjects)

#define    HTML_OBJECTS_OUTPUT   ((*engine).hobjectsout)

#define    HTML_LINE             ((*engine).hline)

#define    HTML_IMAGES_LOAD      ((*engine).himagesload)

#define    HTML_LINE_SIZE        ((*engine).hlinesize)

#define    HTML_BLOCKQUOTE_TAB   ((*engine).hblockquotetab)

#define    HTML_BLOCKDIR_TAB     ((*engine).hblockdirtab)

#define    HTML_HORLINE_SIZE     ((*engine).hhorlinesize)

#define    HTML_DIRLINE_SIZE     ((*engine).hdirlinesize)

#define    HTML_SWITCH_FROM      ((*engine).hswitchfrom)

#define    HTML_STOP_INFO        ((*engine).hstopinfo)

#define    HTML_PATH_TO_FILE     ((*engine).hpathtofile)

#define    HTML_FILE_NAME        ((*engine).hfilename)

#define    HTML_BACKGROUND       ((*engine).hbackground)

#define    HTML_WHERE            ((*engine).hwhere)

#define    HTML_FUNC_REDRAW      ((*engine).hfuncredraw)
#define    HTML_REDRAW()         if ( HTML_FUNC_REDRAW ) (*HTML_FUNC_REDRAW)()


void    html_switch ( HTML_DEF_ENGINE );

#ifndef HTML_FUNC_SWITCH
#define HTML_FUNC_SWITCH(engine)          html_switch(engine)
#endif


html_table  *html_table_make ( HTML_DEF_ENGINE, HTML_DEF_COLOR black, HTML_DEF_COLOR white,
                               HTML_DEF_COLOR ahref, HTML_DEF_BITMAP *back );

#define  HTML_TABLE_MAKE(b,w,a,bk)  html_table_make(b,w,a,bk)

/*
  color declaration
*/
#define HTML_COLOR_BLACK         ((*engine).hcolorblack)
#define HTML_COLOR_WHITE         ((*engine).hcolorwhite)
#define HTML_COLOR_AHREF         ((*engine).hcolorahref)


#define    HTML_RIGHT            HTML_FRAME.hright
#define    HTML_LEFT             HTML_FRAME.hleft
#define    HTML_TOP              HTML_FRAME.htop
#define    HTML_BOTTOM           HTML_FRAME.hbottom



#define HTMLtimes          HTML_OBJECTS.htimes

#define HTMLtype           HTML_OBJECTS.htype
#define HTMLtypefirst      HTML_OBJECTS.htypefirst
#define HTMLtext           HTML_OBJECTS.htext
#define HTMLrect           HTML_OBJECTS.hrect
#define HTMLframe          HTML_OBJECTS.hframe
#define HTMLfont           HTML_OBJECTS.hfont
#define HTMLimage          HTML_OBJECTS.himage
#define HTMLfcolor         HTML_OBJECTS.hfcolor
#define HTMLbcolor         HTML_OBJECTS.hbcolor
#define HTMLalign          HTML_OBJECTS.halign
#define HTMLline           HTML_OBJECTS.hline
#define HTMLfromy          HTML_OBJECTS.hfromy
#define HTMLtypewrite      HTML_OBJECTS.htypewrite
#define HTMLref            HTML_OBJECTS.href
#define HTMLlinesize       HTML_OBJECTS.hlinesize
#define HTMLdirtype        HTML_OBJECTS.hdirtype
#define HTMLdirnumber      HTML_OBJECTS.hdirnumber
#define HTMLenter          HTML_OBJECTS.henter
#define HTMLinsert         HTML_OBJECTS.hinsert
#define HTMLtable          HTML_OBJECTS.htable
#define HTMLnext           HTML_OBJECTS.hnext



html_obs *html_objects_ins ( HTML_DEF_ENGINE, html_obs **main, int type, html_obs *from );
html_obs *html_objects_del ( html_obs **main );
void      html_objects_set_height ( html_obs *main, long line, int height );

html_rect html_line_next ( HTML_DEF_ENGINE, html_rect frame, html_rect r, int hsize );

#define   HTML_OBJECTS_INS(t)  html_objects_ins(engine, &HTML_OBJECTS_OUTPUT, t, &HTML_OBJECTS)
#define   HTML_OBJECTS_DEL()   html_objects_del(&HTML_OBJECTS_OUTPUT)

#define   _HTML_LINE_NEXT(f,r,s)  html_line_next(engine, f, r, s)
#define   HTML_LINE_NEXT(f,r)     _HTML_LINE_NEXT(f, r, HTMLlinesize)



html_com HTMLCOMMANDS[HTML_COMMAND_MAX] = {"HTML", "HEAD", "TITLE", "BODY",
            "H1", "H2", "H3", "H4", "H5", "H6", "P", "PRE", "ADDRESS",
            "BLOCKQUOTE", "UL", "LI", "OL", "DIR", "MENU", "DL", "DT", "DD",
            "I", "B", "CITE", "EM", "STRONG", "VAR", "BR", "HR", "FONT", "A",
            "IMG", "U", "CENTER", "LH", "TABLE", "TD", "TR",
            NULL};

#define  HTMLid(n) ((n<HTML_COMMAND_MAX&&n>=0)?HTMLCOMMANDS[n]:NULL)


#define  HTML_FONT_GETWORDSINWIDTH(f,str,sizex,a)  html_font_get_words_in_width(f, str, sizex, a)


#define  HTML_COLOR_RED(c)                html_color_get_red_from(c)
#define  HTML_COLOR_GREEN(c)              html_color_get_green_from(c)
#define  HTML_COLOR_BLUE(c)               html_color_get_blue_from(c)


/*
  load starndard html_fonts. Use before all html classes call
*/
#ifndef HTML_LOAD_FONT_FUNC

void  html_load_fonts ( void ) {
  char* curdir = getcwd(NULL, HTML_PATH_MAX);
  if ( !chdir(HTML_FONT_DIRECTORY_NAME) ) { /* ok */
    int i = 0;

    HTMLFONTid(HTML_FONT_H6) = HTML_FUNC_FONT_LOAD(HTML_FONT_REGULAR_NAME,  8, 0);
    HTMLFONTid(HTML_FONT_H5) = HTML_FUNC_FONT_LOAD(HTML_FONT_REGULAR_NAME, 10, 10);
    HTMLFONTid(HTML_FONT_H4) = HTML_FUNC_FONT_LOAD(HTML_FONT_REGULAR_NAME, 12, 12);
    HTMLFONTid(HTML_FONT_H3) = HTML_FUNC_FONT_LOAD(HTML_FONT_REGULAR_NAME, 14, 14);
    HTMLFONTid(HTML_FONT_H2) = HTML_FUNC_FONT_LOAD(HTML_FONT_REGULAR_NAME, 18, 18);
    HTMLFONTid(HTML_FONT_H1) = HTML_FUNC_FONT_LOAD(HTML_FONT_REGULAR_NAME, 24, 24);
    HTMLFONTid(HTML_FONT_H0) = HTML_FUNC_FONT_LOAD(HTML_FONT_REGULAR_NAME, 36, 36);

    HTMLFONTid(HTML_FONT_H6_ITALIC) = HTML_FUNC_FONT_LOAD(HTML_FONT_ITALIC_NAME,  8, 8);
    HTMLFONTid(HTML_FONT_H5_ITALIC) = HTML_FUNC_FONT_LOAD(HTML_FONT_ITALIC_NAME, 10, 10);
    HTMLFONTid(HTML_FONT_H4_ITALIC) = HTML_FUNC_FONT_LOAD(HTML_FONT_ITALIC_NAME, 12, 12);
    HTMLFONTid(HTML_FONT_H3_ITALIC) = HTML_FUNC_FONT_LOAD(HTML_FONT_ITALIC_NAME, 14, 14);
    HTMLFONTid(HTML_FONT_H2_ITALIC) = HTML_FUNC_FONT_LOAD(HTML_FONT_ITALIC_NAME, 18, 18);
    HTMLFONTid(HTML_FONT_H1_ITALIC) = HTML_FUNC_FONT_LOAD(HTML_FONT_ITALIC_NAME, 24, 24);
    HTMLFONTid(HTML_FONT_H0_ITALIC) = HTML_FUNC_FONT_LOAD(HTML_FONT_ITALIC_NAME, 36, 36);

    HTMLFONTid(HTML_FONT_H6_BOLD) = HTML_FUNC_FONT_LOAD(HTML_FONT_BOLD_NAME,  8, 8);
    HTMLFONTid(HTML_FONT_H5_BOLD) = HTML_FUNC_FONT_LOAD(HTML_FONT_BOLD_NAME, 10, 10);
    HTMLFONTid(HTML_FONT_H4_BOLD) = HTML_FUNC_FONT_LOAD(HTML_FONT_BOLD_NAME, 12, 12);
    HTMLFONTid(HTML_FONT_H3_BOLD) = HTML_FUNC_FONT_LOAD(HTML_FONT_BOLD_NAME, 14, 14);
    HTMLFONTid(HTML_FONT_H2_BOLD) = HTML_FUNC_FONT_LOAD(HTML_FONT_BOLD_NAME, 18, 18);
    HTMLFONTid(HTML_FONT_H1_BOLD) = HTML_FUNC_FONT_LOAD(HTML_FONT_BOLD_NAME, 24, 24);
    HTMLFONTid(HTML_FONT_H0_BOLD) = HTML_FUNC_FONT_LOAD(HTML_FONT_BOLD_NAME, 36, 36);

    HTMLFONTid(HTML_FONT_H6_BI) = HTML_FUNC_FONT_LOAD(HTML_FONT_BOLDITALIC_NAME,  8, 8);
    HTMLFONTid(HTML_FONT_H5_BI) = HTML_FUNC_FONT_LOAD(HTML_FONT_BOLDITALIC_NAME, 10, 10);
    HTMLFONTid(HTML_FONT_H4_BI) = HTML_FUNC_FONT_LOAD(HTML_FONT_BOLDITALIC_NAME, 12, 12);
    HTMLFONTid(HTML_FONT_H3_BI) = HTML_FUNC_FONT_LOAD(HTML_FONT_BOLDITALIC_NAME, 14, 14);
    HTMLFONTid(HTML_FONT_H2_BI) = HTML_FUNC_FONT_LOAD(HTML_FONT_BOLDITALIC_NAME, 18, 18);
    HTMLFONTid(HTML_FONT_H1_BI) = HTML_FUNC_FONT_LOAD(HTML_FONT_BOLDITALIC_NAME, 24, 24);
    HTMLFONTid(HTML_FONT_H0_BI) = HTML_FUNC_FONT_LOAD(HTML_FONT_BOLDITALIC_NAME, 36, 36);


    chdir(curdir);
  } else html_err_func("HTML fonts directory not found.");
  free(curdir);
};

#endif



/*
  destroy starndard html_fonts. Use after all html classes end-call
*/
void  html_unload_fonts ( void ) {
  int n = 0;
  while ( n < HTML_FONT_MAX ) {
    HTML_FUNC_FONT_UNLOAD(HTMLFONTid(n));
    HTMLFONTS[n] = NULL;
    n++;
  };
};




/*
  return origins in html_rect structure
*/
static html_rect rect_assign ( long left, long top, long right, long bottom )
{
  html_rect r;
  r.hleft   = left;
  r.htop    = top;
  r.hright  = right;
  r.hbottom = bottom;
  return r;
};



/*
  return origins in html_rect structure
*/
static html_rect rect_move ( html_rect r, long dx, long dy )
{
  html_rect d;
  d.hleft   = r.hleft+dx;
  d.htop    = r.htop+dy;
  d.hright  = r.hright+dx;
  d.hbottom = r.hbottom+dy;
  return d;
};



/*
  return sizex
*/
static long rect_sizex ( html_rect r )
{
  return (r.hright-r.hleft);
};


/*
  return sizey
*/
static long rect_sizey ( html_rect r )
{
  return (r.hbottom-r.htop);
};



/*
  from "c" return red color
  F.e. "c" == 0xFF0015
  Red color is FF
  Green color is 00
  Blue color is 15
*/
unsigned char  html_color_get_red_from ( unsigned long c )
{
  unsigned long red = (c>>16);
  return ((unsigned char)red);
};



unsigned char  html_color_get_green_from ( unsigned long c )
{
  unsigned long green = ((c<<16)>>24);
  return ((unsigned char)green);
};



unsigned char  html_color_get_blue_from ( unsigned long c )
{
  unsigned long blue = ((c<<24)>>24);
  return ((unsigned char)blue);
};



/*
  return type of font in id, we want to get from fnt. Type can be one of
  FONT_NORMAL, FONT_ITALIC, FONT_BOLD, FONT_BI.
  F.e. : fnt is HTML_FONT_H1 and type is FONT_BOLD we now get
  HTML_FONT_H1_BOLD...
*/
int  change_type_of_font ( int fnt, char type ) {

  fnt = max(0, min(HTML_FONT_MAX, fnt)); /* set font to range of fonts */

  if ( type != HTML_FONT_NORMAL && fnt >= HTML_FONTS ) /* if type of font is not normal */
     return (HTML_FONT_BI*HTML_FONTS+(fnt%HTML_FONTS)); /* mix two fonts type */
  else return (type*HTML_FONTS+(fnt%HTML_FONTS));

  return -1; /* it's not possible */
};


/*
  return type of font fnt. F.e. HTML_FONT_H3_ITALIC
  else return -1;
*/
int   ret_type_of_font ( HTML_DEF_FONT *fnt ) {
  int n = 0;
  while ( n < HTML_FONT_MAX ) {
    if ( HTMLFONTid(n) == fnt ) return n;
    n++;
  };
  return -1;
};




/*
  return main type of font fnt. F.e. HTML_ITALIC
*/
int   ret_maintype_of_font ( int fnt ) {
  return (fnt/max(1, HTML_FONTS));
};



/*
  return changed weight of font fnt. F.e. font is HTML_FONT_H3_ITALIC
  and weight is 6, it return HTML_FONT_H1_ITALIC
  else return -1;
*/
int   change_weight_of_font ( int fnt, int weight ) {

  int t;

  fnt = max(0, min(HTML_FONT_MAX, 0)); /* set font to range of fonts */

  t = ((fnt/max(1, HTML_FONTS))*HTML_FONTS); /* go to start of type */

  if ( weight <= HTML_FONTS )
    return t+HTML_FONTS-max(1, weight);
  else return t;  /* else return max weight font */

  return -1; /* not possible */
};



/*
  return weight of font fnt. F.e. font is HTML_FONT_H3_ITALIC
  returned value will be 3
*/
int   ret_weight_of_font ( int fnt ) {

  return (fnt%HTML_FONTS)+1;

};



/*
  return alignmet in TX_ALIGN_... format form text.
  text can be "center", "left", "right", "bottom", "top"
  If nothing of format, it return standard 0 = TX_ALIGN_LEFT.
*/
int   ret_align_id_from_str ( char *str )
{
  if ( str ) {
    if ( !stricmp(str, "center") ) return HTML_ALIGN_CENTERX;
    if ( !stricmp(str, "left") ) return HTML_ALIGN_LEFT;
    if ( !stricmp(str, "right") ) return HTML_ALIGN_RIGHT;
    if ( !stricmp(str, "bottom") ) return HTML_ALIGN_BOTTOM;
    if ( !stricmp(str, "top") ) return HTML_ALIGN_TOP;
  };
  return 0;
};



/*
  return size from string to integer
  isdelta indicates if string has +/- before number
*/
long   ret_size_id_from_str ( char *str, int *isdelta )
{
  #define whattype() do {                             \
      if ( (o = strchr(str, '-')) ) isminus = 1;      \
      else o = strchr(str, '+');                      \
      if ( o ) str = o+1;                             \
  } while (0)

  long  l = 0;
  int   isminus = 0;
  char *o = NULL;
  if ( str ) {
    if ( !strncmp(str, HTML_HEXANUM, strlen(HTML_HEXANUM)) ) { /* found hex number */
      int size = strlen(str)+strlen(C_HEXANUM)-strlen(HTML_HEXANUM)+1;
      char *v = (char *)malloc(size);
      if ( v ) {
        whattype();
        bzero(v, size);
        strcat(v, C_HEXANUM);
        strcat(v, str+strlen(HTML_HEXANUM));
        l = strtol(v, NULL, 0);
        free(v);
      };
    } else {
      whattype();
      l = strtol(str, NULL, 0);
    };
    if ( isdelta )
      if ( o ) *isdelta = 1; /* found +/- character */
      else *isdelta = 0;
    return (isminus?(-l):(l));
  };
  if ( isdelta ) *isdelta = 0;
  return 0;
};



/*
  test if char is one of html banks chars. HTML banks chars means the chars
  which can be used for dividing words. < > space
*/
static int hsch ( char ch ) {
  long n = 0;
  while ( n < html_bankspc_char_size ) {
    if ( ch == html_bankspc_char[n] ) return 1;
    n++;
  };
  return 0;
};



/*
  test if char is one of html space chars. HTML space chars means the chars
  which can be used for dividing words in normal text
*/
static int hsnch ( char ch ) {
  long n = html_space_char_size-1;
  while ( n >= 0 ) {
    if ( ch == html_space_char[n] ) return 1;
    n--;
  };
  return 0;
};




/*
  calculate how many chars in words can be visible in width w and frame allx
*/
int  html_font_get_words_in_width ( HTML_DEF_FONT *f, char *str, int w, int allx ) {
  int words = 0;
  if ( str && f && w > 0 ) {
    int n = 0;
    while ( w > 0 && *str ) {
      w -= HTML_FUNC_FONT_GETCHARWIDTH(f, *str);
      if ( w > 0 && hsnch(*str) )
        words = n+1;
      str++;
      n++;
    };
    if ( !words && allx > w ) return 0;
    if ( !words || w > 0 ) return max(1, n);
    return words;
  };
  return 0;
};



char*  firstrefnchar ( char *str ) {

  if ( str ) {
    while ( *str ) {
      if ( !hsnch(*str) ) return str;
      str++;
    };
  };
  return NULL;
};



char *reformattext ( char *str, int firstok ) {
  if ( str ) {
    long  s = strlen(str);
    char *p = NULL;
    char  prev = firstok?'a':html_space_char[0];
    if ( s > 1 ) p = (char*)malloc(s+1);
    if ( p ) {
      char *o = p;
      char *oldstr = str;
      memset(p, 0, s+1);
      while ( *str ) {
        if ( !hsnch(*str) || !hsnch(prev) ) {
          *p = *str;
          p++;
          prev = *str;
        };
        str++;
      };
      if ( o && ( !(*o) || (!(*(o+1)) && hsnch(*o))) ) {
        free(o);
        o = NULL;
      };
      return o;
    };
  };
  return NULL;
};



/*
  duplicate str by max length in num
*/
static char *strnewn ( char *str, long num ) {
  if ( str && num > 0 ) {
    char *b = (char *)malloc(num+1);
    bzero(b, num+1);
    strncpy(b, str, num);
    return b;
  };
  return NULL;
};


/*
  <p align="center">Uniforms</p>
  if this is declaration, com will be:  align="center"
  and by "align" in to variable this function return "center"
*/

static char *find_first_not_c ( char *p, char c ) {
  if ( p )
    while ( *p ) {
      if ( *p != c ) return p;
      p++;
    };
  return NULL;
};

static char *find_first_is_bank ( char *p ) {
  if ( p )
    while ( *p ) {
      if ( hsch(*p) ) return p;
      p++;
    };
  return NULL;
};

static char *html_commander ( char *com, char *to ) {
  char *tcom = strlwr(strdup(com));
  char *tto  = strlwr(strdup(to));
  char *p = strstr(tcom, tto);
  char *old = p;
  if ( p ) {
    p = strchr(p, '=');
    if ( p ) {
      old = p;
      p = strchr(p+1, '"');
      if ( !p ) p = find_first_not_c(old+1, ' ');
      if ( p ) {
        char *n = strchr(p+1, '"');
        if ( !n ) n = find_first_is_bank(p+1);
        if ( !n ) {
          char *v = strdup(p);
          free(tcom);
          free(tto);
          return v;
        } else
        if ( n-p > 1 ) {
          char *v = strnewn(com+((p+1)-tcom), (n-p)-1);
          free(tcom);
          free(tto);
          return v;
        };
      };
    };
  };
  free(tcom);
  free(tto);
  return NULL;
};



/*
  find next occurence of character.
  if found it, it return position of pointer+1, else return NULL
*/
static char *fnext ( char *str1, char *str2 ) {
  char *p = strstr(str1, str2);
  return ((p)?p+1:NULL);
};




/*
  return commands from text. F.e. <body bgcolor="#FFFFFF">
    - return upper commands => BODY
*/
static char  *find_html_start ( html_com *c, char *text ) {
  long items = 0; /* how many commands we know */
  long maxsize = 0, t = 0;
  if ( text )
    while ( items < HTML_COMMAND_MAX && c[items] ) { /* while c[item] is not NULL */
      long size = strlen(c[items]);
      char *i = strupr(strnewn(text, size));
      if ( !strncmp(i, c[items], size) ) /* if strings are same */
        if ( size > maxsize && (!text[size-1] || hsch(text[size])) ) {
          t = items;
          maxsize = size;
        };
      free(i);
      items++;
    };
  /* if commad exist */
  if ( maxsize ) return strupr(strdup(c[t]));
  return NULL;
};



/* - HTML DOWNLOADED OBJECTS **************************************** */

/*
  find object by "id"-identification string in "main" structure and return
  pointer to obj. If not exist this "id" return NULL;
*/
void*   html_obj_get_downloads ( html_dwns *main, char *id )
{
  if ( id ) { /* if "id" is string */
    while ( main ) {
      #ifdef __DOWNLOADED_DISCERN_LWUP_CHARS__
      if ( !strcmp(main->hid, id) ) /* discern lower & upper chars */
      #else
      if ( !stricmp(main->hid, id) ) /* same for lower & upper chars */
      #endif
        return main->hptr; /* found id object and return it */

      main = main->hnext;
    };
  };
  return NULL;
};



/*
  make new object by "id" string and "ptr"-pointer to object and insert it
  to main directory of objects. if main directory not exist it return
  new main directory, otherwise it return old main directory

  NOTE: object will be create only if not exist yet !!
*/

html_dwns   *html_obj_ins_downloads ( html_dwns **main, char *id, int idnum, void *ptr )
{
  html_dwns *newd = NULL;

  if ( main && html_obj_get_downloads(*main, id) ) /* test if was defined */
    return *main; /* this "id" is defined yet */

  newd = (html_dwns*)malloc(sizeof(html_dwns));
  if ( newd ) {
    bzero(newd, sizeof(html_dwns));
    newd->hnext  = NULL;
    newd->hid    = strdup(id);
    newd->hidnum = idnum;
    newd->hptr   = ptr;
    if ( main ) { /* if ptr to main exist */
      if ( *main ) newd->hnext = *main; /* main exist */
      *main = newd;
    };
  };
  if ( !main ) return newd;
  return (*main);
}


#define HTML_BITMAP  1
#define HTML_TEXT    2

void  html_how_delete ( int id, void *p ) {
 if ( p )
   switch ( id ) {
     case HTML_BITMAP : HTML_FUNC_BITMAP_DESTROY((HTML_DEF_BITMAP *)p); break;
     default    : free(p);
   };
};



/*
  delete all obj in main directory and return NULL
*/
html_dwns    *html_obj_del_downloads ( html_dwns **main )
{
  if ( main ) { /* ptr exist */
    while ( *main ) {
      html_dwns *old = *main;
      html_how_delete(old->hidnum, old->hptr);
      free(old->hid); /* free memory for text id */
      (*main) = (*main)->hnext;
      free(old);
    };
    *main = NULL;
  };
  return NULL;
};



char *html_path2file ( char *path, char *id )
{
  if ( path && id ) {
    char *v = (char *)malloc(strlen(path)+strlen(id)+1);
    if ( v ) { /* path & string exist */
      *v = '\0'; /* set 0 for concating of 2 strings */
      strcat(v, path);
      strcat(v, id);
      return v;
    };
    return NULL; /* not enough memory to allocate string */
  } else if ( id ) return strdup(id); /* path is null so read only a file if exist */
  return NULL;
};



char *html_filefrompath ( char *path )
{
  if ( path ) {
    int sz = strlen(path);
    if ( path[sz-1] == '/' || path[sz-1] == '\\' ) /* end of path */
      return path;
    else {
      char *last_slash1 = strrchr(path, '/');
      char *last_slash2 = strrchr(path, '\\');
      if ( last_slash1 && *(last_slash1+1) ) /* end char is not / */
        return strdup(last_slash1+1);
      else
        if ( last_slash2 && *(last_slash2+1) ) /* end char is not \ */
          return strdup(last_slash2+1);
    };
  };
  return NULL;
};



/*
  download file or load file from disk and return ptr
*/
void  *html_obj_load_downloads ( html_dwns *main, char *path, char *id, int idnum )
{
  #define ret(x) do {     \
    free(id);             \
    return x;             \
  } while (0)

  void *p = NULL;

  id = html_path2file(path, id);

  p = html_obj_get_downloads(main, id);

  if ( p ) ret(p);

  switch  ( idnum ) {
    case IMG_S : { /* IMAGE */
      ret(HTML_FUNC_BITMAP_LOAD(id));
    }; break;
  };
};



/* - HTML OBJECTS ******************************************************** */
/*
  insert new object to "main" object directory. If "main" exist it copy
  last definition of object to new object and return new object.
  if "main" directory not exist, it make new object and return it.
*/
html_obs *html_objects_ins ( HTML_DEF_ENGINE, html_obs **main, int type, html_obs *from )
{
  html_obs *newd = NULL;
  html_obs *last = NULL;
  if ( main ) {
    html_obs *m = *main;
    while ( m ) {
      last = m;
      m = m->hnext;
    };
  };


  newd = (html_obs*)malloc(sizeof(html_obs));
  if ( newd ) {
    if ( !from ) memset(newd, 0, sizeof(html_obs));
    else memcpy(newd, from, sizeof(html_obs));
    if ( last ) last->hnext = newd;
    newd->hnext  = NULL;
    newd->htype  = type;
    newd->htext  = strdup(newd->htext);
    newd->href   = strdup(newd->href);
    newd->hline  = HTML_LINE;
    if ( main && !last ) *main = newd;
  };
  return newd;
};



/*
  delete all html objects structure
*/
html_obs *html_objects_del ( html_obs **main )
{
  if ( main ) { /* ptr exist */
    while ( *main ) {
      html_obs *old = *main;
      html_how_delete(HTML_TEXT, old->htext);
      html_how_delete(HTML_TEXT, old->href);
      html_how_delete(HTML_BITMAP, old->himage);
      (*main) = (*main)->hnext;
      free(old);
    };
    *main = NULL;
  };
  return NULL;
};



/*
  set max height of object
*/
void  html_objects_set_height ( html_obs *main, long line, int height )
{
   while ( main ) {
     if ( main->hline == line )
        main->hrect.hbottom = main->hrect.htop+height;
     main = main->hnext;
   };
};



/*
  set left originx and right originx by last object's alignment in "line"
  This settings are providing in all objects in "line"
*/
void  html_objects_set_width ( html_obs *main, long line )
{
   long allx = 0;
   long maxl = 0;
   long maxr = 0;
   long deltax = 0;
   int  align = -1;
   html_obs *om = main;
   while ( main ) {
     if ( main->hline < line ) om = main;
     if ( main->hline == line ) {
         if ( align == -1 ) align = main->halign;
         allx += rect_sizex(main->hrect);
         maxl  = lmax(maxl, main->hframe.hleft);
         maxr  = lmax(maxr, main->hframe.hright);
     };
     main = main->hnext;
   };

   if ( align & HTML_ALIGN_CENTERX )
      deltax = (((maxr-maxl)>>1)-(allx>>1))-maxl;
   else
   if ( align & HTML_ALIGN_LEFT )
      deltax = 0;
   else
   if ( align & HTML_ALIGN_RIGHT )
      deltax = (maxr-allx)-maxl;

   main = om;
   while ( main ) {
     if ( main->hline == line ) {
       main->halign &= ~0x1F;
       main->halign |= HTML_ALIGN_LEFT;
       main->hrect  = rect_move(main->hrect, deltax, 0);
     } else if ( main->hline > line ) break;
     main = main->hnext;
   };
};




/*
  make new structure of table,
  where black is color of text,
        white is color of background,
        ahref is color of reference's text,
        back  is image of background

  return NULL if not enough memory to alocate this structure
*/
html_table  *html_table_make ( HTML_DEF_ENGINE, HTML_DEF_COLOR black, HTML_DEF_COLOR white,
                               HTML_DEF_COLOR ahref, HTML_DEF_BITMAP *back )
{
  html_table *t = (html_table *)malloc(sizeof(html_table));

  if ( t ) { /* ok in allocating of memory */

    HTMLtable = t; /* set as current table */

    memset(t, 0, sizeof(html_table)); /* it's good to set memory to zero */

    t->hcolorblack = black;
    t->hcolorwhite = white;
    t->hcolorahref = ahref;
    t->hbackground = back;

  };

  return t;
};


#endif


