/*

  FreeHyperText 1.0 - library for easy HTML files loading

  Copyright (c) 1999 by Michal Stencl


  HTML2.C       is used for basic definitions.
  HTML2FNC.C    main translating functions

   o   This code is absolutly FREE.
   o   It's easy to port to all systems
   o   Please, if you any questions or ideas feel free to contact me at:


  e-mail:  stenclpmd@ba.telecom.sk

  web   :  http://www.home.sk/public/fht/

  web   :  http://www.home.sk/public/stencl/
*/

#ifndef __FHT_HTMLFNC2_INCLUDED__
#define __FHT_HTMLFNC2_INCLUDED__


#include"html2.c"

/*
  moving function. This function move to next line from r and return new
  rect
*/
html_rect HTML_CLASS(html_line_next ( HTML_DEF_ENGINE, html_rect frame, html_rect r, int hsize ))
{
  html_rect d;
  d.htop = r.hbottom+hsize;
  d.hbottom = d.htop+hsize;
  d.hleft = frame.hleft;
  d.hright = frame.hright;
  html_objects_set_width(HTML_OBJECTS_OUTPUT, HTML_LINE);
  HTML_FUNC_SWITCH(engine);
  HTML_LINE++;
  return d;
};




/*
  switch to draw function.
  HTML_SWITCHER is increasing in this function to zero.
  When is zero, HTML_SWITCHER = HTML_SWITCH_INTERVAL and go again.
*/
void  HTML_CLASS(html_switch ( HTML_DEF_ENGINE ))
{
   if ( HTML_LINE > HTML_SWITCH_FROM ) {

     HTML_FRAMEOUT = HTML_FRAME; /* set outputs */
     HTML_FRAMEOUT.hbottom = HTMLrect.hbottom;

     HTML_REDRAW();
   };
};


#define HTML_OBJECTS_SET_HEIGHT(l,h)   _HTML_OBJECTS_SET_HEIGHT(engine, l, h)
#define HTML_OBJECTS_INS2(t,h,w)       _HTML_OBJECTS_INS2(engine, t, h, w)


/*
  set max height of objects in "line"
*/
void  _HTML_OBJECTS_SET_HEIGHT ( HTML_DEF_ENGINE, long line, int height )
{
  if ( HTMLrect.hbottom-HTMLrect.htop < height ) {
    HTMLrect.hbottom = HTMLrect.htop+height;
    html_objects_set_height(HTML_OBJECTS_OUTPUT, line, height);
  };
};


/*
  insert object to html objects directory and set his height to height
  and hrect.hright to hrect.hleft+width
*/
void  _HTML_OBJECTS_INS2 ( HTML_DEF_ENGINE, int type, int height, int width )
{
  long oldhr = HTMLrect.hright; /* push right origin */
  html_obs *cur = NULL;
  if ( width != -1 )
    HTMLrect.hright = HTMLrect.hleft+width; /* move right origin for insert */

  cur = HTML_OBJECTS_INS(type);
  if ( cur ) {
    HTML_OBJECTS_SET_HEIGHT(HTML_LINE, height);
    cur->hfromy = rect_sizey(cur->hrect)-height;
  };
  HTMLrect.hright = oldhr; /* pop right origin */
};



/*
  make new HTMLtext depend on comm ( PARAGRAPH_S, PRE_S, ... )
  if PARAGRAPH_S
    - reformat text and ignore first space character, if I'm first in line
*/
char  *HTML_MAKE_HTEXT ( HTML_DEF_ENGINE, char *text, int comm )
{
  char *v = NULL;
  if ( text && *text )
    switch ( HTMLtypewrite ) { /* only for strdup */
      case  PARAGRAPH_S : {
        v = reformattext(text, HTMLrect.hleft!=HTMLframe.hleft); /* make HTMLtext from text */
      }; break;
      default :
        v = strdup(text);
    };

  return v;
};



FILE *TEST = NULL;

/*
  - DRAW TEXT FUNCTION **********************************************
*/
/*
  main outputs function
  text is text that comes to object
  comm is command IMG_S, PARAGRAPH_S....
  flow indicates, if text was divide because of length of line
  flow = 1 - text was divided
  flow = 0 - text wasn't divided => it's the first calling of this function in
                                    specific command
*/
char  *HTML_CLASS(html_text ( HTML_DEF_ENGINE, char *text, int comm, int flow ))
{

  char *ret = NULL; /* value to be return */
  char *v = NULL;

  HTMLrect.hleft = max(HTMLframe.hleft, HTMLrect.hleft); /* redefine left origin */

  if ( comm == -1 ) comm = HTMLtype;

  if ( text && *text ) HTMLtext = strdup(text); /* make new HTMLtext */
  else HTMLtext = NULL;

  if ( TEST ) fprintf(TEST, text); /* only for testing */

  if ( HTMLtypewrite == PARAGRAPH_S &&
        HTMLtext ) { /* type of write is PARAGRAPH_S */

    if ( !stricmp(HTMLtext, "&nbsp;") ) { /* it's not text but new br line */
       free(HTMLtext);
       HTMLtext = NULL;

    } else { /* it's <p> text type */

       char *p  = HTMLtext;
       int size = HTML_FONT_GETWORDSINWIDTH(HTMLFONTid(HTMLfont), p,
                                 rect_sizex(HTMLrect), rect_sizex(HTMLframe));
       int strs = strlen(p);

         if ( size < strs && size > 0 ) { /* I divide <p> */

             HTMLtext = strnewn(p, size); /* align size of HTMLtext */

             free(p);
             /* insert object to object directory right HERE ! */
             HTML_OBJECTS_INS2(HTMLtype, HTML_FUNC_FONT_GETHEIGHT(HTMLFONTid(HTMLfont)), -1);

             HTMLrect = _HTML_LINE_NEXT(HTMLframe, HTMLrect, HTML_DIRLINE_SIZE);
             ret = (text+size); /* I want new line */

         } else
         {
           int lsize = HTML_FUNC_FONT_GETSTRWIDTH(HTMLFONTid(HTMLfont), p, strs);

           if ( !flow && lsize+HTMLrect.hleft > HTMLframe.hright ) {

             HTMLrect = _HTML_LINE_NEXT(HTMLframe, HTMLrect, HTML_DIRLINE_SIZE);
             ret = text;

           } else {
             HTML_OBJECTS_INS2(HTMLtype, HTML_FUNC_FONT_GETHEIGHT(HTMLFONTid(HTMLfont)), lsize);
             HTMLrect.hleft += lsize;
             /* insert object to object directory right HERE ! */
           };
         };
     };
  } else
   /* IMAGE */
  if ( HTMLtypewrite == IMG_S ) {

     int sizex = HTML_BITMAP_NOSIZEX;
     int sizey = HTML_BITMAP_NOSIZEY;

     if ( HTMLimage ) {
       sizex = HTML_FUNC_BITMAP_GETWIDTH(HTMLimage);
       sizey = HTML_FUNC_BITMAP_GETHEIGHT(HTMLimage);
     };

     HTML_OBJECTS_INS2(HTMLtype, sizey, sizex);
     HTMLrect.hleft += sizex;

  }  else
    /* HORIZONTAL LINE TEXT */
  if ( HTMLtypewrite == HR_S ) {

     if ( !HTMLenter && HTMLframe.htop != HTMLrect.htop ) /* wasn't enter or not start of page */
       HTMLrect = HTML_LINE_NEXT(HTMLframe, HTMLrect);
     HTML_OBJECTS_INS2(HTMLtype, HTML_HORLINE_SIZE, -1);
     HTMLrect = HTML_LINE_NEXT(HTMLframe, HTMLrect);

  } else
    /* PREFORMATED TEXT */
  if ( HTMLtypewrite == PRE_S &&
       HTMLtext ) {

       char *p  = strchr(HTMLtext, 10); /* 10 - break line */
       int   s  = p?((p-HTMLtext)+1):-1;
       int   size = -1;

       if ( s != -1 ) { /* if found enter character */
         free(HTMLtext);
         HTMLtext = strnewn(text,s);
       };

       size = HTML_FUNC_FONT_GETSTRWIDTH(HTMLFONTid(HTMLfont), HTMLtext, strlen(HTMLtext));

       HTML_OBJECTS_INS2(HTMLtype, HTML_FUNC_FONT_GETHEIGHT(HTMLFONTid(HTMLfont)), size);

       if ( s != -1 ) { /* found enter character */
          HTMLrect = _HTML_LINE_NEXT(HTMLframe, HTMLrect, HTML_DIRLINE_SIZE);
          ret = (text+s);
       } else HTMLrect.hleft += size;
       HTMLtypefirst = PRE_S;
  };

  if ( HTMLtypewrite != PRE_S )
     HTMLtypefirst = PARAGRAPH_S;


  free(HTMLtext);
  HTMLtext = NULL;

  return ret; /* return value */
};




void  html_set_standard_align ( HTML_DEF_ENGINE, void *com )
{
  char *align = html_commander((char *)com, "align"); /* get alignment of paragraph */
  if ( align ) HTMLalign = HTMLALIGNid(align); /* set alignment of paragraph */
  free(align);
};



void  html_set_standard_font ( HTML_DEF_ENGINE, void *com )
{
  char *font  = html_commander((char *)com, "size");  /* get size of font */
  char *color = html_commander((char *)com, "color"); /* get color of font */
  html_set_standard_align(engine, com);
  if ( font ) { /* set size of font */
    int isdelta; /* get if font size is delta from old size */
    int size = HTMLSIZEIDid(font, &isdelta); /* get size of font */
    int nwsz = isdelta?HTML_FONT_WEIGHT(HTMLfont)+size:size;
    HTMLfont = HTML_FONT_CHANGE_WEIGHT(HTMLfont, nwsz);
  };
  if ( color ) /* set color of font */
    HTMLfcolor = HTML_FUNC_COLOR_MAKERGB(HTML_COLOR_RED(HTMLSIZEid(color)),
                                         HTML_COLOR_GREEN(HTMLSIZEid(color)),
                                         HTML_COLOR_BLUE(HTMLSIZEid(color)));
  free(font);
  free(color);
};




long  __html_noftype ( char **ptr, int hcom, int hend, long num, int *subdir )
{
  #define where (*ptr)


  where = strstr(where, BEGIN_S); /* find < character */

  if ( where && strstr(where, END_S) != where ) { /* if next character is not /  */
    char *com = find_html_start(HTMLCOMMANDS, where+strlen(BEGIN_S));
    if ( !stricmp(com, HTMLid(hend) ) ) { /* I found subdir of hend commander */
      (*subdir)++;
      where++;
    } else
    if ( !(*subdir) && !stricmp(com, HTMLid(hcom) ) ) { /* ! found hcom & i'm not in subdir */
       return __html_noftype(ptr, hcom, hend, num+1, subdir);
    };
  } else if ( where ) { /* these characters are /> */
    char *com = find_html_start(HTMLCOMMANDS, where+strlen(END_S));
    if ( !stricmp(com, HTMLid(hend) ) ) { /* I found end of subdir of hend commander */
      if ( (*subdir) <= 0 ) return num;  /* end of process */
      else {
        (*subdir)--; /* only decrease subdir of hend command */
        where++;
      };
    };
  };

  return 0;
};




long  html_noftype ( HTML_DEF_ENGINE, int hcom, int hend )
{

  char *w = engine->hwhere;

  long  num = 0;
  int   subdir = 0;

  while ( w ) {
     num = __html_noftype(&w, hcom, hend, num, &subdir);
  };

  return num;

};




/*
  - TRANSLATE FUNCTION **********************************************
*/
int   HTML_CLASS(html_func_trans ( HTML_DEF_ENGINE, char *command, void* com ))
{

  /*
     make new line if prev command not made it. This must be called before
     HTML_TIMES[t]++ call.
  */
  #define HTML_ENTER(t)                                   \
    if ( !HTML_TIMES[t] && !HTMLenter ) {                 \
       HTMLrect = HTML_LINE_NEXT(HTMLframe, HTMLrect);    \
       HTMLenter = 1;                                     \
    }

  #define HTML_ENTER_OP()  do {                           \
       HTMLrect = HTML_LINE_NEXT(HTMLframe, HTMLrect);    \
       HTMLenter = 1;                                     \
    } while (0)


  int res = 1;


  if ( TEST ) fprintf(TEST, "%s%s%s", "<", command, ">");

  if ( !stricmp(command, HTMLid(HTML_S)) ) /* if command is HTML */
  {
    HTMLtype = HTMLtypefirst = HTML_S;
    HTML_TIMES[HTML_S]++;
    res = 1;
  } else
  if ( !stricmp(command, HTMLid(HEAD_S)) ) /* if command is HEAD */
  {
    HTMLtype = HTMLtypefirst = HTMLtypewrite = HEAD_S;
    HTML_TIMES[HEAD_S]++;
    res = 1;
  } else
  if ( !stricmp(command, HTMLid(TITLE_S)) ) /* if command is TITLE */
  {
    HTMLtype = HTMLtypefirst = HTMLtypewrite = TITLE_S;
    HTML_TIMES[TITLE_S]++;
    res = 1;
  } else
  if ( !stricmp(command, HTMLid(BODY_S)) ) /* if command is BODY */
  {
    char *back   = html_commander((char *)com, "background"); /* get background image */
    char *bcolor = html_commander((char *)com, "bgcolor"); /* get color of background */
    char *text   = html_commander((char *)com, "text"); /* get color of text in html */
    char *alink  = html_commander((char *)com, "alink"); /* get color of alinked text in html */
    char *vlink  = html_commander((char *)com, "vlink"); /* get color of vlinked text in html */
    char *link   = html_commander((char *)com, "link"); /* get color of linked text in html */
    HTMLtype = BODY_S;
    HTMLtypewrite = PARAGRAPH_S;
    HTML_TIMES[BODY_S]++;


    if ( bcolor ) { /* set background of html */
      HTMLbcolor = HTML_FUNC_COLOR_MAKERGB(HTML_COLOR_RED(HTMLSIZEid(bcolor)),
                                           HTML_COLOR_GREEN(HTMLSIZEid(bcolor)),
                                           HTML_COLOR_BLUE(HTMLSIZEid(bcolor)));
      HTML_COLOR_WHITE = HTMLbcolor;
    };

    if ( text ) { /* set text color in html */
      HTMLfcolor = HTML_FUNC_COLOR_MAKERGB(HTML_COLOR_RED(HTMLSIZEid(text)),
                                           HTML_COLOR_GREEN(HTMLSIZEid(text)),
                                           HTML_COLOR_BLUE(HTMLSIZEid(text)));
      HTML_COLOR_BLACK = HTMLfcolor;
    };

    if ( link ) /* set color of linked text in html */
      HTML_COLOR_AHREF = HTML_FUNC_COLOR_MAKERGB(HTML_COLOR_RED(HTMLSIZEid(link)),
                                           HTML_COLOR_GREEN(HTMLSIZEid(link)),
                                           HTML_COLOR_BLUE(HTMLSIZEid(link)));
    if ( back && HTML_IMAGES_LOAD ) { /* set background image */
      HTML_DEF_BITMAP *img = (HTML_DEF_BITMAP *)HTML_DOWNLOADS_LOAD(back, IMG_S);
      HTML_DOWNLOADS_INS(back, IMG_S, img); /* insert to dwns directory, if not yet */
      HTMLimage = img;
      HTML_BACKGROUND = img;
    };

    free(link);
    free(vlink);
    free(alink);
    free(bcolor);
    free(text);
    free(back);
    res = 1;
  } else
  if ( !stricmp(command, HTMLid(H1_S)) ) /* if command is H1 */
  {
    HTML_ENTER(H1_S); /* make new line if not made in previous command */
    html_set_standard_font(engine, com);
    HTMLtype = HTMLtypefirst = H1_S;
    HTMLtypewrite = PARAGRAPH_S;
    HTMLfont = HTML_FONT_H1;
    HTML_TIMES[H1_S]++;
    res = 1;
  } else
  if ( !stricmp(command, HTMLid(H2_S)) ) /* if command is H2 */
  {
    HTML_ENTER(H2_S); /* make new line if not made in previous command */
    html_set_standard_font(engine, com);
    HTMLtype = HTMLtypefirst = H2_S;
    HTMLtypewrite = PARAGRAPH_S;
    HTMLfont = HTML_FONT_H2;
    HTML_TIMES[H2_S]++;
    res = 1;
  } else
  if ( !stricmp(command, HTMLid(H3_S)) ) /* if command is H3 */
  {
    HTML_ENTER(H3_S); /* make new line if not made in previous command */
    html_set_standard_font(engine, com);
    HTMLtype = HTMLtypefirst = H3_S;
    HTMLtypewrite = PARAGRAPH_S;
    HTMLfont = HTML_FONT_H3;
    HTML_TIMES[H3_S]++;
    res = 1;
  } else
  if ( !stricmp(command, HTMLid(H4_S)) ) /* if command is H4 */
  {
    HTML_ENTER(H4_S); /* make new line if not made in previous command */
    html_set_standard_font(engine, com);
    HTMLtype = HTMLtypefirst = H4_S;
    HTMLtypewrite = PARAGRAPH_S;
    HTMLfont = HTML_FONT_H4;
    HTML_TIMES[H4_S]++;
    res = 1;
  } else
  if ( !stricmp(command, HTMLid(H5_S)) ) /* if command is H5 */
  {
    HTML_ENTER(H5_S); /* make new line if not made in previous command */
    html_set_standard_font(engine, com);
    HTMLtype = HTMLtypefirst = H5_S;
    HTMLfont = HTML_FONT_H5;
    HTMLtypewrite = PARAGRAPH_S;
    HTML_TIMES[H5_S]++;
    res = 1;
  } else
  if ( !stricmp(command, HTMLid(H6_S)) ) /* if command is H6 */
  {
    HTML_ENTER(H6_S); /* make new line if not made in previous command */
    html_set_standard_font(engine, com);
    HTMLtype = HTMLtypefirst = H6_S;
    HTMLtypewrite = PARAGRAPH_S;
    HTMLfont = HTML_FONT_H6;
    HTML_TIMES[H6_S]++;
    res = 1;
  } else
  if ( !stricmp(command, HTMLid(PARAGRAPH_S)) ) /* if command is PARAGRAPH */
  {
    if ( HTML_TIMES[PARAGRAPH_S] ) { /* old type of HTML */
      HTMLrect = HTML_LINE_NEXT(HTMLframe, HTMLrect);
      HTMLenter = 1;
    } else
      HTML_ENTER(PARAGRAPH_S); /* make new line if not made in previous command */
    HTML_TIMES[PARAGRAPH_S]++;
    html_set_standard_align(engine, com);
    HTMLtype = HTMLtypefirst = HTMLtypewrite = PARAGRAPH_S;
    res = 1;
  } else
  if ( !stricmp(command, HTMLid(PRE_S)) ) /* if command is PRE */
  {
    HTML_ENTER(PRE_S); /* make new line if not made in previous command */
    HTML_TIMES[PRE_S]++;
    HTMLtype = HTMLtypewrite = HTMLtypefirst = PRE_S;
    res = 1;
  } else
  if ( !stricmp(command, HTMLid(ADDRESS_S)) ) /* if command is ADDRESS */
  {
    HTML_TIMES[ADDRESS_S]++;
    res = 1;
  } else
  if ( !stricmp(command, HTMLid(BLOCKQUOTE_S)) ) /* if command is BLOCKQUOTE */
  {
    HTMLframe.hleft += HTML_BLOCKQUOTE_TAB; /* move x position */
    HTML_ENTER(BLOCKQUOTE_S); /* make new line if not made in previous command */
    HTML_TIMES[BLOCKQUOTE_S]++;
    HTMLtype = HTMLtypefirst = BLOCKQUOTE_S;
    HTMLtypewrite = PARAGRAPH_S;
    res = 1;
  } else
  if ( !stricmp(command, HTMLid(UL_S)) ) /* if command is UL */
  {
    HTMLframe.hleft += HTML_BLOCKQUOTE_TAB;
    HTMLrect = HTML_LINE_NEXT(HTMLframe, HTMLrect);
    HTML_TIMES[UL_S]++;
    HTMLtype = HTMLtypefirst = UL_S;
    HTMLtypewrite = PARAGRAPH_S;
    HTMLdirtype = UL_S;
    HTMLdirnumber = 0;
    res = 1;
  } else
  if ( !stricmp(command, HTMLid(LI_S)) ) /* if command is LI */
  {
    if ( HTMLdirnumber > 0 ) /* I'm not first it the dir */
      HTMLrect = HTML_LINE_NEXT(HTMLframe, HTMLrect);

    HTMLenter = 1;
    HTML_TIMES[LI_S]++;
    HTMLlinesize = HTML_DIRLINE_SIZE;
    HTMLtype = HTMLtypefirst = LI_S;
    HTMLtypewrite = PARAGRAPH_S;
    HTMLinsert = 1;
    HTMLdirnumber++;
    res = 1;
  } else
  if ( !stricmp(command, HTMLid(OL_S)) ) /* if command is OL */
  {
    HTML_TIMES[OL_S]++;
    HTMLtype = HTMLtypefirst = OL_S;
    HTMLframe.hleft += HTML_BLOCKQUOTE_TAB;
    HTMLrect = HTML_LINE_NEXT(HTMLframe, HTMLrect);
    HTMLenter = 1;
    HTMLlinesize = HTML_DIRLINE_SIZE;
    HTMLdirtype = OL_S;
    HTMLdirnumber = 0;
    res = 1;
  } else
  if ( !stricmp(command, HTMLid(DIR_S)) ) /* if command is DIR */
  {
    HTML_TIMES[DIR_S]++;
    res = 1;
  } else
  if ( !stricmp(command, HTMLid(MENU_S)) ) /* if command is MENU */
  {
    HTML_TIMES[MENU_S]++;
    res = 1;
  } else
  if ( !stricmp(command, HTMLid(LH_S)) ) /* if command is LH */
  {
    HTML_TIMES[LH_S]++;
    HTMLtype = HTMLtypefirst = LH_S;
    HTMLdirnumber = 0;
    res = 1;
  } else
  if ( !stricmp(command, HTMLid(DL_S)) ) /* if command is DL */
  {
    HTML_TIMES[DL_S]++;
    HTMLtype = HTMLtypefirst = DL_S;
    HTMLframe.hleft += HTML_BLOCKDIR_TAB;
    HTMLrect = HTML_LINE_NEXT(HTMLframe, HTMLrect);
    HTMLdirtype = DL_S;
    res = 1;
  } else
  if ( !stricmp(command, HTMLid(DT_S)) ) /* if command is DT */
  {
    HTMLtype = HTMLtypefirst = PARAGRAPH_S;
    HTMLlinesize = HTML_DIRLINE_SIZE;
    HTMLframe.hleft = max(HTML_LEFT, HTMLframe.hleft-HTML_BLOCKDIR_TAB);
    HTMLrect = HTML_LINE_NEXT(HTMLframe, HTMLrect);
    HTML_TIMES[DT_S]++;
    res = 1;
  } else
  if ( !stricmp(command, HTMLid(DD_S)) ) /* if command is DD */
  {
    HTMLtype = HTMLtypefirst = DD_S;
    HTMLframe.hleft += HTML_BLOCKDIR_TAB;
    if ( HTMLrect.hleft > HTMLframe.hleft )
       HTMLrect = HTML_LINE_NEXT(HTMLframe, HTMLrect);
    HTML_TIMES[DD_S]++;
    HTMLtypewrite = PARAGRAPH_S;
    res = 1;
  } else
  if ( !stricmp(command, HTMLid(ITALIC_S)) ) /* if command is ITALIC */
  {
    HTML_TIMES[ITALIC_S]++;
    HTMLfont = HTML_FONT_CHANGE_TYPE(HTMLfont, HTML_FONT_ITALIC);
    res = 1;
  } else
  if ( !stricmp(command, HTMLid(BOLD_S)) ) /* if command is BOLD */
  {
    HTML_TIMES[BOLD_S]++;
    HTMLfont = HTML_FONT_CHANGE_TYPE(HTMLfont, HTML_FONT_BOLD);
    res = 1;
  } else
  if ( !stricmp(command, HTMLid(CITE_S)) ) /* if command is CITE */
  {
    HTML_TIMES[CITE_S]++;
    res = 1;
  } else
  if ( !stricmp(command, HTMLid(EM_S)) ) /* if command is EM */
  {
    HTML_TIMES[EM_S]++;
    HTMLfont = HTML_FONT_CHANGE_TYPE(HTMLfont, HTML_FONT_BOLD);
    res = 1;
  } else
  if ( !stricmp(command, HTMLid(STRONG_S)) ) /* if command is STRONG */
  {
    HTML_TIMES[STRONG_S]++;
    HTMLfont = HTML_FONT_CHANGE_TYPE(HTMLfont, HTML_FONT_BOLD);
    res = 1;
  } else
  if ( !stricmp(command, HTMLid(VAR_S)) ) /* if command is VAR */
  {
    HTML_TIMES[VAR_S]++;
    res = 1;
  } else
  if ( !stricmp(command, HTMLid(BR_S)) ) /* if command is BR */
  {
    HTML_TIMES[BR_S]++;
    HTMLrect = HTML_LINE_NEXT(HTMLframe, HTMLrect);
    HTMLtypefirst = HTMLtypewrite = HTMLtype = -1;
    res = -1;
  } else
  if ( !stricmp(command, HTMLid(HR_S)) ) /* if command is HR */
  {
    HTML_TIMES[HR_S]++;
    HTMLtypewrite = HTMLtype = HR_S;
    html_text(engine, NULL, HR_S, 0); /* insert object */
    HTMLtypefirst = HTMLtypewrite = HTMLtype = -1;
    res = -1;
  } else
  if ( !stricmp(command, HTMLid(FONT_S)) ) /* if command is FONT */
  {
    html_set_standard_font(engine, com);
    HTML_TIMES[FONT_S]++;
    res = 1;
  } else
  if ( !stricmp(command, HTMLid(AHREF_S)) ) /* if command is A HREF */
  {
    char *ref  = html_commander((char *)com, "ref");  /* get size of font */
    HTML_TIMES[AHREF_S]++;
    HTMLtype = HTMLtypefirst = AHREF_S;
    HTMLtypewrite = PARAGRAPH_S;
    HTMLalign |= HTML_ALIGN_UNDERLINED;
    HTMLfcolor = HTML_COLOR_AHREF;
    HTMLref = ref;
    res = 1;
  } else
  if ( !stricmp(command, HTMLid(IMG_S)) ) /* if command is IMG */
  {
    HTML_TIMES[IMG_S]++;
    HTMLtype = HTMLtypewrite = HTMLtypefirst = IMG_S;

    if ( HTML_IMAGES_LOAD ) { /* may I load images ? */
       char *src = html_commander((char *)com, "src"); /* get source of image */
       char *wdt = html_commander((char *)com, "width"); /* get width of image */
       char *hgt = html_commander((char *)com, "height"); /* get height of image */
       int   width;  /* width of image */
       int   height; /* height of image */

       html_set_standard_align(engine, com); /* set alignment */

       if ( src ) { /* found source */
         HTML_DEF_BITMAP *img = (HTML_DEF_BITMAP *)HTML_DOWNLOADS_LOAD(src, IMG_S);
         if ( img ) { /* if image was loaded */
           width = HTML_FUNC_BITMAP_GETWIDTH(img);
           height = HTML_FUNC_BITMAP_GETHEIGHT(img);

           if ( wdt ) /* there is redeclaration of width */
             width = max(0, HTMLSIZEid(wdt));  /* set new width of image */
           if ( hgt ) /* there is redeclaration of width */
             height = max(0, HTMLSIZEid(hgt));  /* set new height of image */

           HTML_DOWNLOADS_INS(src, IMG_S, img); /* insert to dwns directory, if not yet */

           img = HTML_FUNC_BITMAP_STRETCH(img, width, height); /* stretch and return new bitmap */
           HTMLimage = img; /* set image */

           html_text(engine, NULL, IMG_S, 0); /* insert object */
         };
         free(src);
       };
       free(wdt);
       free(hgt);
    };
    HTMLimage = NULL;
    res = -1;
  } else
  if ( !stricmp(command, HTMLid(U_S)) ) /* if command is U */
  {
    HTMLalign |= HTML_ALIGN_UNDERLINED;
    HTML_TIMES[U_S]++;
    res = 1;
  } else
  if ( !stricmp(command, HTMLid(CENTER_S)) ) /* if command is CENTER */
  {
    HTMLalign = HTML_ALIGN_CENTERX;
    HTML_TIMES[CENTER_S]++;
    res = 1;
  }
  /* not found, set as standard */
    else {
      HTMLtype = HTMLtypewrite = HTMLtypefirst = PARAGRAPH_S;
    };


  HTMLrect.hleft = max(HTMLframe.hleft, HTMLrect.hleft); /* redefine left origin */

  return res;
};



/*
  - RESET OBJECTS FUNCTIONS *********************************************
*/
void  HTML_CLASS(html_func_reset_objects ( HTML_DEF_ENGINE, html_obs *obs ))
{
  if ( obs ) {

    HTMLenter = obs->henter;
    HTMLtext = NULL;
    HTMLalign = obs->halign;
    HTMLfcolor = obs->hfcolor;
    HTMLbcolor = obs->hbcolor;
    HTMLfont = obs->hfont;
    HTMLframe = obs->hframe;
    HTMLimage = obs->himage;
    HTMLtype = obs->htype;
    HTMLtypewrite = obs->htypewrite;
    HTMLlinesize = obs->hlinesize;
    HTMLref = obs->href;
    HTMLdirtype = obs->hdirtype;
    HTMLtypefirst = 0;
    HTMLinsert = obs->hinsert;

  } else { /* set standard */

    bzero(&HTML_OBJECTS, sizeof(html_obs));
    HTMLenter = 0;
    HTMLtypewrite = PARAGRAPH_S;
    HTMLfcolor = HTML_COLOR_BLACK;
    HTMLbcolor = HTML_COLOR_WHITE;
    HTMLlinesize = HTML_LINE_SIZE;
    HTMLfont = HTML_FONT_H4;
    HTMLframe = rect_assign(HTML_LEFT, HTML_TOP, HTML_RIGHT, HTML_BOTTOM);
    HTMLrect  = rect_assign(HTMLframe.hleft, HTMLframe.htop, HTMLframe.hright, HTMLframe.htop);

  };
};


/*
  - RESET FUNCTION ********************************************************
*/
int   HTML_CLASS(html_func_reset ( HTML_DEF_ENGINE, char *command, void* com ))
{
  #define  RESET() do {                                  \
    if ( !was_reset ) {                                  \
      html_func_reset_objects(engine, (html_obs*)com);   \
      free(com);                                         \
    };                                                   \
    was_reset = 1;                                       \
  } while (0)

  #define  HRESET() do {                                 \
    if ( !was_reset ) {                                  \
      html_func_reset_objects(engine, (html_obs*)com);   \
      free(com);                                         \
      HTMLenter = 0;                                     \
    };                                                   \
    was_reset = 1;                                       \
  } while (0)

  #define  TIMES_MINUS(com)                              \
    if ( HTML_TIMES[com] > 0 ) HTML_TIMES[com]--         \



  int res = 0;
  int was_reset = 0;
  if ( TEST ) fprintf(TEST, "%s%s%s", "</", command, ">");

  if ( !stricmp(command, HTMLid(HTML_S)) ) /* if command is HTML */
  {
    TIMES_MINUS(HTML_S);

  } else
  if ( !stricmp(command, HTMLid(HEAD_S)) ) /* if command is HEAD */
  {
    TIMES_MINUS(HEAD_S);

  } else
  if ( !stricmp(command, HTMLid(TITLE_S)) ) /* if command is TITLE */
  {
    TIMES_MINUS(TITLE_S);

  } else
  if ( !stricmp(command, HTMLid(BODY_S)) ) /* if command is BODY */
  {
    TIMES_MINUS(BODY_S);

  } else
  if ( !stricmp(command, HTMLid(H1_S)) ) /* if command is H1 */
  {
    HRESET();
    TIMES_MINUS(H1_S);
  } else
  if ( !stricmp(command, HTMLid(H2_S)) ) /* if command is H2 */
  {
    HRESET();
    TIMES_MINUS(H2_S);

  } else
  if ( !stricmp(command, HTMLid(H3_S)) ) /* if command is H3 */
  {
    HRESET();
    TIMES_MINUS(H3_S);

  } else
  if ( !stricmp(command, HTMLid(H4_S)) ) /* if command is H4 */
  {
    HRESET();
    TIMES_MINUS(H4_S);

  } else
  if ( !stricmp(command, HTMLid(H5_S)) ) /* if command is H5 */
  {
    HRESET();
    TIMES_MINUS(H5_S);

  } else
  if ( !stricmp(command, HTMLid(H6_S)) ) /* if command is H6 */
  {
    HRESET();
    TIMES_MINUS(H6_S);

  } else
  if ( !stricmp(command, HTMLid(PARAGRAPH_S)) ) /* if command is PARAGRAPH */
  {
    HRESET();
    TIMES_MINUS(PARAGRAPH_S);

  } else
  if ( !stricmp(command, HTMLid(PRE_S)) ) /* if command is PRE */
  {
    HRESET();
    TIMES_MINUS(PRE_S);

  } else
  if ( !stricmp(command, HTMLid(ADDRESS_S)) ) /* if command is ADDRESS */
  {
    HRESET();
    TIMES_MINUS(ADDRESS_S);

  } else
  if ( !stricmp(command, HTMLid(BLOCKQUOTE_S)) ) /* if command is BLOCKQUOTE */
  {
    HRESET();
    TIMES_MINUS(BLOCKQUOTE_S);

  } else
  if ( !stricmp(command, HTMLid(UL_S)) ) /* if command is UL */
  {
    HRESET();
    TIMES_MINUS(UL_S);

  } else
  if ( !stricmp(command, HTMLid(LI_S)) ) /* if command is LI */
  {
    HRESET();
    TIMES_MINUS(LI_S);

  } else
  if ( !stricmp(command, HTMLid(OL_S)) ) /* if command is OL */
  {
    HRESET();
    TIMES_MINUS(OL_S);

  } else
  if ( !stricmp(command, HTMLid(DIR_S)) ) /* if command is DIR */
  {
    HRESET();
    TIMES_MINUS(DIR_S);

  } else
  if ( !stricmp(command, HTMLid(MENU_S)) ) /* if command is MENU */
  {
    HRESET();
    TIMES_MINUS(MENU_S);

  } else
  if ( !stricmp(command, HTMLid(DL_S)) ) /* if command is DL */
  {
    HRESET();
    TIMES_MINUS(DL_S);

  } else
  if ( !stricmp(command, HTMLid(LH_S)) ) /* if command is LH */
  {
    HRESET();
    TIMES_MINUS(LH_S);

  } else
  if ( !stricmp(command, HTMLid(DT_S)) ) /* if command is DT */
  {
    HRESET();
    TIMES_MINUS(DT_S);
    if ( !HTML_TIMES[DT_S] ) /* last <DT> */
      HTMLrect = HTML_LINE_NEXT(HTMLframe, HTMLrect);

  } else
  if ( !stricmp(command, HTMLid(DD_S)) ) /* if command is DD */
  {
    HRESET();
    TIMES_MINUS(DD_S);

  } else
  if ( !stricmp(command, HTMLid(ITALIC_S)) ) /* if command is ITALIC */
  {
    TIMES_MINUS(ITALIC_S);

  } else
  if ( !stricmp(command, HTMLid(BOLD_S)) ) /* if command is BOLD */
  {
    TIMES_MINUS(BOLD_S);

  } else
  if ( !stricmp(command, HTMLid(CITE_S)) ) /* if command is CITE */
  {
    TIMES_MINUS(CITE_S);

  } else
  if ( !stricmp(command, HTMLid(EM_S)) ) /* if command is EM */
  {
    TIMES_MINUS(EM_S);

  } else
  if ( !stricmp(command, HTMLid(STRONG_S)) ) /* if command is STRONG */
  {
    TIMES_MINUS(STRONG_S);

  } else
  if ( !stricmp(command, HTMLid(VAR_S)) ) /* if command is VAR */
  {
    TIMES_MINUS(VAR_S);

  } else
  if ( !stricmp(command, HTMLid(BR_S)) ) /* if command is BR */
  {
    TIMES_MINUS(BR_S);

  } else
  if ( !stricmp(command, HTMLid(HR_S)) ) /* if command is HR */
  {
    TIMES_MINUS(HR_S);

  } else
  if ( !stricmp(command, HTMLid(FONT_S)) ) /* if command is FONT */
  {
    TIMES_MINUS(FONT_S);

  } else
  if ( !stricmp(command, HTMLid(AHREF_S)) ) /* if command is A HREF */
  {
    TIMES_MINUS(AHREF_S);

  } else
  if ( !stricmp(command, HTMLid(IMG_S)) ) /* if command is IMG */
  {
    TIMES_MINUS(IMG_S);

  } else
  if ( !stricmp(command, HTMLid(U_S)) ) /* if command is U */
  {
    TIMES_MINUS(U_S);

  } else
  if ( !stricmp(command, HTMLid(CENTER_S)) ) /* if command is CENTER */
  {
    TIMES_MINUS(CENTER_S);

  };

 RESET(); /* only run if not reset before */
 return res;
};





/*
  - GET FUNCTION ********************************************************
*/
void* HTML_CLASS(html_func_get ( HTML_DEF_ENGINE, char *command ))
{
  html_obs *get = (html_obs*)malloc(sizeof(html_obs));
  memcpy(get, &HTML_OBJECTS, sizeof(html_obs));

  if ( !stricmp(command, HTMLid(HTML_S)) ) /* if command is HTML */
  {

  } else
  if ( !stricmp(command, HTMLid(HEAD_S)) ) /* if command is HEAD */
  {

  } else
  if ( !stricmp(command, HTMLid(TITLE_S)) ) /* if command is TITLE */
  {

  } else
  if ( !stricmp(command, HTMLid(BODY_S)) ) /* if command is BODY */
  {

  } else
  if ( !stricmp(command, HTMLid(H1_S)) ) /* if command is H1 */
  {

  } else
  if ( !stricmp(command, HTMLid(H2_S)) ) /* if command is H2 */
  {

  } else
  if ( !stricmp(command, HTMLid(H3_S)) ) /* if command is H3 */
  {

  } else
  if ( !stricmp(command, HTMLid(H4_S)) ) /* if command is H4 */
  {

  } else
  if ( !stricmp(command, HTMLid(H5_S)) ) /* if command is H5 */
  {

  } else
  if ( !stricmp(command, HTMLid(H6_S)) ) /* if command is H6 */
  {

  } else
  if ( !stricmp(command, HTMLid(PARAGRAPH_S)) ) /* if command is PARAGRAPH */
  {

  } else
  if ( !stricmp(command, HTMLid(PRE_S)) ) /* if command is PRE */
  {

  } else
  if ( !stricmp(command, HTMLid(ADDRESS_S)) ) /* if command is ADDRESS */
  {

  } else
  if ( !stricmp(command, HTMLid(BLOCKQUOTE_S)) ) /* if command is BLOCKQUOTE */
  {

  } else
  if ( !stricmp(command, HTMLid(UL_S)) ) /* if command is UL */
  {

  } else
  if ( !stricmp(command, HTMLid(LI_S)) ) /* if command is LI */
  {

  } else
  if ( !stricmp(command, HTMLid(OL_S)) ) /* if command is OL */
  {

  } else
  if ( !stricmp(command, HTMLid(DIR_S)) ) /* if command is DIR */
  {

  } else
  if ( !stricmp(command, HTMLid(MENU_S)) ) /* if command is MENU */
  {

  } else
  if ( !stricmp(command, HTMLid(LH_S)) ) /* if command is LH */
  {

  } else
  if ( !stricmp(command, HTMLid(DL_S)) ) /* if command is DL */
  {

  } else
  if ( !stricmp(command, HTMLid(DT_S)) ) /* if command is DT */
  {

  } else
  if ( !stricmp(command, HTMLid(DD_S)) ) /* if command is DD */
  {

  } else
  if ( !stricmp(command, HTMLid(ITALIC_S)) ) /* if command is ITALIC */
  {

  } else
  if ( !stricmp(command, HTMLid(BOLD_S)) ) /* if command is BOLD */
  {

  } else
  if ( !stricmp(command, HTMLid(CITE_S)) ) /* if command is CITE */
  {

  } else
  if ( !stricmp(command, HTMLid(EM_S)) ) /* if command is EM */
  {

  } else
  if ( !stricmp(command, HTMLid(STRONG_S)) ) /* if command is STRONG */
  {

  } else
  if ( !stricmp(command, HTMLid(VAR_S)) ) /* if command is VAR */
  {

  } else
  if ( !stricmp(command, HTMLid(BR_S)) ) /* if command is BR */
  {

  } else
  if ( !stricmp(command, HTMLid(HR_S)) ) /* if command is HR */
  {

  } else
  if ( !stricmp(command, HTMLid(FONT_S)) ) /* if command is FONT */
  {

  } else
  if ( !stricmp(command, HTMLid(AHREF_S)) ) /* if command is A HREF */
  {

  } else
  if ( !stricmp(command, HTMLid(IMG_S)) ) /* if command is IMG */
  {

  } else
  if ( !stricmp(command, HTMLid(U_S)) ) /* if command is U */
  {

  } else
  if ( !stricmp(command, HTMLid(CENTER_S)) ) /* if command is CENTER */
  {

  };

  return get;
};




/*
  - MAIN TRANSLATING PROCESS ********************************************
*/
int   HTML_CLASS(html_translate ( HTML_DEF_ENGINE, char **_text, char *old_com ))
{
  #define start (*_text)

  HTML_WHERE = start; /* set current ptr in file */

  while ( start && !HTML_STOP_INFO /* until process isn't stop */ ) {
    char *old  = start;
    char *htx  = NULL;
    char *otx = NULL;
    int   flow = 0; /* indicates first calling of text */
    start = strstr(start, BEGIN_S);
    htx = otx = strnewn(old, start-old);
    htx = HTML_MAKE_HTEXT(engine, htx, HTMLtypewrite);
    free(otx);
    otx = htx;
    if ( !htx && HTMLinsert ) HTML_OBJECTS_INS(HTMLtype);
    while ( htx ) {
      htx = html_text(engine, htx, -1, flow); /* call function for classic html text */
      flow = 1;
    };
    free(otx);
    /* test if found character '<' and if next character is not '/' */
    if ( start && strstr(start, END_S) != start ) { /* ok */
         /* find character '>', what ends html command */
         char *end = strstr(start+strlen(BEGIN_S), BEGIN_E);
         long size = lmax(0, end-(start+1)); /* look for length between '<' and '>' */
         /* find command word frowm html_funcs list */
         char *command = find_html_start(HTMLCOMMANDS, start+strlen(BEGIN_S));
         /* look for parameter. parameter is between '<command' and '>' */
         char *param = command?strnewn(start+strlen(command), lmax(0, (size-strlen(command))+1)):NULL;
         /* look for function in html_funcs table */
         if ( command ) { /* command was found */
             void *v = html_func_get(engine, command); /* gets old values of command */
             /* call func of command translating. If func return zero,
               we cannot call func by old values. If return nonzero, we
               must set old values. */
             int resel = html_func_trans(engine, command, param);
             start = end?end+1:NULL; /* I move start only if i know command */
             if ( resel > 0 ) html_translate(engine, &start, command); /* go to subprocess - call self */
             if ( resel ) html_func_reset(engine, command, v); /* restore values of command */
             free(v); /* gets-function returned pointer to allocated structure of command
                         so we must destroy it */
         } else start = fnext(start, BEGIN_E); /* If I don't know command I move pos of start to next '>' cahracter */
         free(command); /* free memory from param */
         free(param); /* free memory from command */
    } else { /* if not found char '<' or next character was '/' */
        if ( start ) { /* I found char -> next character was '/' */
          char *s = find_html_start(HTMLCOMMANDS, start+strlen(END_S)); /* look for command */
          if ( old_com && s && stricmp(old_com, s) ) { /* no this must be previus command */
            free(s);
            return 0;
          };
          start = fnext(start, END_E); /* if i'm sure that next character was '/' move to next '>' char +1 */
          if ( s ) { /* found command */
            free(s);
            return 0;
          }; /* didn't find command, continue... */
          free(s);
        } else return 0; /* didn't found '<' */
      };
  };
  return 0;
};



/*
  only load filename.
  if filename not found , it return NULL, else return pointer to memory
  where is store text of filename.
*/
char *HTML_CLASS(html_load_file ( char *_filename ))
{
  FILE *f = fopen(_filename, "rt");
  if ( !f ) { /* file not found */
    html_err_func("File %s couldn't be open. Some error occurs. Try check path to file.", _filename);
    return NULL;
  } else {
    long  size = filelength(fileno(f)); /* get size of file */
    char *txt = (char *)malloc(size+1); /* malloc size of file */
    if ( !txt ) { /* if there isnt's enough memory */
      html_err_func("There is not enough memory to load file %s", _filename);
      fclose(f); /* must close file */
      return NULL;
    } else {
      bzero(txt, size); /* I like to set memory to zero. It's quickly. */
      fread(txt, size, 1, f); /* read file to memory */
      fclose(f);  /* close file */
      return txt; /* and return memory to text of file */
    };
  };
  return NULL; /* ever when not good process */
};




html_engine  *HTML_CLASS(html_engine_new ( long left, long top, long right, long bottom,
                                           int lnh, int blocktab, int dirtab,
                                           int imgload, int hlnh, int dirlnh,
                                           int swfrom, void (*funcredraw)() ))
{
  html_engine *engine = (html_engine*)malloc(sizeof(html_engine));
  if ( engine ) { /* if there is enough memory */
    memset(engine, 0, sizeof(html_engine));

    HTML_FRAME = rect_assign(left, top, right, bottom);
    HTML_COLOR_BLACK            = HTML_FUNC_COLOR_MAKERGB(0x00, 0x00, 0x00);
    HTML_COLOR_WHITE            = HTML_FUNC_COLOR_MAKERGB(0xC0, 0xC0, 0xC0);
    HTML_COLOR_AHREF            = HTML_FUNC_COLOR_MAKERGB(0x00, 0x00, 0xC0);
    HTML_LINE_SIZE              = lnh;
    HTML_BLOCKQUOTE_TAB         = blocktab;
    HTML_BLOCKDIR_TAB           = dirtab;
    HTML_IMAGES_LOAD            = imgload;
    HTML_HORLINE_SIZE           = hlnh;
    HTML_DIRLINE_SIZE           = dirlnh;
    HTML_SWITCH_FROM            = swfrom;
    HTML_FUNC_REDRAW            = funcredraw;

    html_func_reset_objects(engine, NULL);
  };
  return engine;
};



char *html_file2path ( char *path )
{
  if ( path ) {
    int sz = strlen(path);
    if ( path[sz-1] == '/' || path[sz-1] == '\\' ) /* end of path */
      return path;
    else {
      char *last_slash1 = strrchr(path, '/');
      char *last_slash2 = strrchr(path, '\\');
      if ( last_slash1 > last_slash2 ) /* last_slash1 WON !!! */
        return strnewn(path, (last_slash1-path)+1);
      else /* no last_slash1 was !last but one! and I was the SECOND !!! */
        if ( last_slash2 ) return strnewn(path, (last_slash2-path)+1);
    };
  };
  return NULL;
};



void  HTML_CLASS(html_engine_out ( html_engine *engine, char *filename ))
{
  if ( engine ) { /* only if engine exist */
    char *p, *o;
    int   i;
    HTML_PATH_TO_FILE = html_file2path(filename);
    HTML_FILE_NAME = html_filefrompath(filename);
    o = p = html_load_file(filename);
    i = 0;
    while ( p && !HTML_STOP_INFO ) {
      i = html_translate(engine, &p, NULL);
      if ( i ) html_err_func("%d", i);
    };
    free(o);
    HTML_FRAMEOUT = HTML_FRAME;
    HTML_STOP_INFO = 2;
    HTML_FRAMEOUT.hbottom = HTMLrect.hbottom;
  };
};


void  html_engine_del ( html_engine **engine )
{
  if ( engine ) {
    if ( *engine ) {
      html_objects_del(&((**engine).hobjectsout));
      free((**engine).hpathtofile);
      free((**engine).hfilename);
      memset(*engine, 0, sizeof(html_engine));
      free(*engine);
   };
   *engine = NULL;
 };
};


#endif


#ifndef __UNIFORMS_H_INCLUDED__
int main ( void ) {

  char c[3];

  html_engine *engine;

  html_obs *out;
  html_obs *old;
  FILE *fo;

  engine  = html_engine_new(0, 0, 79, 24, 1, 5, 3, 0, 1, 1, 1, NULL);

  TEST = fopen("ex.to", "wt");

   /*
     I defineed new html for text mode, where

     1. left   origin is 0
     2. top    origin is 0
     3. right  origin is 79
     4. bottom origin is 24
     5. size between lines is 1
     6. block tabulation is   5
     7. dir   tabulation is   3
     8. I don't want to load images  0
     9. Horizontal line height is 1
    10. Line between 2 lines in dir type is 1
    11. The first calling of function hfuncredraw ( now it's NULL ) will
        be from the 1st line
   */


  /*
    - load html fonts, if you not set fonts loading function it makes nothing
  */
  html_load_fonts();



  /*
    - put output to engine.hobjectsout from file "ex.htm"
  */
  html_engine_out(engine, "ex.htm");

  if ( engine ) /* test if engine exist => system had enough memory for
  {                html loading and file exist */

    old = out = engine->hobjectsout;


    fo = fopen("exout.to" ,"wt");  /* make file for output */

    /* puts to demo file name of author and version of FHT */
    fprintf(fo, "\n%s version %s by %s\n", __FREE_HYPER_TEXT_NAME__,
                                           __FREE_HYPER_TEXT_VERSION__,
                                           __FREE_HYPER_TEXT_AUTHOR__);

    fprintf(fo, "-----------------------------------------------------------------------\n");


    old = NULL;

    while ( out ) {  /* repeat until the last object == NULL */

      char *mf = NULL;

      memset(c, 0, 3);

      /* transform aligment to chars */

      if ( out->halign & HTML_ALIGN_RIGHT ) c[0] = 'R';
      if ( out->halign & HTML_ALIGN_LEFT ) c[0] = 'L';
      if ( out->halign & HTML_ALIGN_CENTERX ) c[0] = 'C';

      if ( out->halign & HTML_ALIGN_UNDERLINED ) c[1] = 'U';


      /* transform font types to chars */

      if ( HTML_FONT_MAINTYPE(out->hfont) == HTML_FONT_NORMAL ) mf = "R";
      if ( HTML_FONT_MAINTYPE(out->hfont) == HTML_FONT_BOLD ) mf = "B";
      if ( HTML_FONT_MAINTYPE(out->hfont) == HTML_FONT_BI ) mf = "BI";
      if ( HTML_FONT_MAINTYPE(out->hfont) == HTML_FONT_ITALIC ) mf = "I";

      /* if next line, print it to file */

      if ( !old || out->hline != old->hline )
         fprintf(fo, "\nLine number #%i\n", out->hline);

      /* ...and write to file basic object settings */

      fprintf(fo, "<%s | text=%s | ref=%s | align=%s | fontsize=%i | type=%s | fcolor=%i | rect=%i %i %i %i >\n\n",
                HTMLid(out->htype), out->htext, out->href, c, HTML_FONT_WEIGHT(out->hfont),
                mf, out->hfcolor,
                out->hrect.hleft, out->hrect.htop, out->hrect.hright, out->hrect.hbottom);

      old = out;

      out = out->hnext; /* move to next object */

    };

    fclose(fo); /* close output file */

    html_engine_del(&engine); /* close html_engine */

    html_unload_fonts(); /* unload fonts */

    fclose(TEST);

    return 0;
};
#endif
